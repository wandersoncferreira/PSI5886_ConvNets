from keras.datasets import mnist

(X_treino, y_treino), (X_teste, y_teste) = mnist.load_data()
